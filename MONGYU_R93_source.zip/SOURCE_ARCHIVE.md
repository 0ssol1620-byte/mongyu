# R93 current player source archive

This archive contains the current original-file host and metadata evidence, not historical authored-game engines. The repository retains historical R92 code and its legacy tests; the README legacy test command applies only to that full repository.

Run `python3 scripts/test.py` to validate and generate Android assets, then `ANDROID_SDK_ROOT=/path/to/sdk python3 android/build-unsigned.py`. Use Node 22+, Python 3.10+, Android SDK/platform/build-tools 36 and JDK 17. Browser QA additionally requires Playwright and Chromium. An original game is not provided. Never put a private game file in the source/build/release directory.

FILE_MANIFEST.json hashes every other archive entry and records the runtime-tested commit separately from documentation. No signing key, commercial game data or final APK is present. The pinned WIE runtime is open source; attribution and licenses are under web/original/licenses.
