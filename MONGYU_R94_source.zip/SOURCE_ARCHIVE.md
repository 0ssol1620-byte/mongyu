# Standalone R94 source

No original game file or proprietary original assets are needed or included. This is the authored MONGYU game, not a verified identical reproduction of NOM3.

Run python3 scripts/test.py, then ANDROID_SDK_ROOT=/path/to/sdk python3 android/build-unsigned.py with Node 22, Python 3.10+, JDK17 and Android SDK36. The test/build script creates the single offline HTML and Android generated assets. The Android upgrade QA script requires a git checkout with the historical R93 commit; it is not runnable from a ZIP alone. Browser QA needs Playwright, Chromium and a server for the repository root on port4173.

FILE_MANIFEST.json hashes all other entries. No signing key or final APK is included. web/assets/music carries the licensed recordings and full attribution. Historical unused prototype image assets may be present for regression tests but are not embedded in the shipped game.
